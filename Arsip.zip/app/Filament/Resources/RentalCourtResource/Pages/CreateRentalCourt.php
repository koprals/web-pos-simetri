<?php

namespace App\Filament\Resources\RentalCourtResource\Pages;

use App\Filament\Resources\RentalCourtResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRentalCourt extends CreateRecord
{
    protected static string $resource = RentalCourtResource::class;
}
