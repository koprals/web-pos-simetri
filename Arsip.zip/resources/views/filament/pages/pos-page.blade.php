<x-filament-panels::page>

    @livewire('pos')

</x-filament-panels::page>
