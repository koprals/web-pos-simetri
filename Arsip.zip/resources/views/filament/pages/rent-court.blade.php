<x-filament-panels::page>

    @livewire('rent-court')

</x-filament-panels::page>
