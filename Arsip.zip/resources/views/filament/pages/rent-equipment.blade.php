<x-filament-panels::page>

    @livewire('rent-equipment')

</x-filament-panels::page>
